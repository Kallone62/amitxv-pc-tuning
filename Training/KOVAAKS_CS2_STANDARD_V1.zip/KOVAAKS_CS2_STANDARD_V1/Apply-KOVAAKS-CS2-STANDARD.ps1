$ErrorActionPreference = 'Stop'
$ProfileName = 'KOVAAKS_CS2_STANDARD_V1'
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

function Write-Utf8NoBom([string]$Path, [string]$Text) {
    $enc = New-Object System.Text.UTF8Encoding($false)
    $Text = $Text -replace "`r?`n", "`r`n"
    [System.IO.File]::WriteAllText($Path, $Text, $enc)
}

function Find-KovaaksProjectDir {
    $steamRoots = New-Object System.Collections.Generic.List[string]
    foreach ($regPath in @('HKCU:\Software\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam','HKLM:\SOFTWARE\Valve\Steam')) {
        try {
            $p = (Get-ItemProperty -Path $regPath -ErrorAction Stop).SteamPath
            if (-not $p) { $p = (Get-ItemProperty -Path $regPath -ErrorAction Stop).InstallPath }
            if ($p -and (Test-Path $p)) { $steamRoots.Add($p) }
        } catch {}
    }
    foreach ($p in @([Environment]::GetFolderPath('ProgramFilesX86') + '\Steam', [Environment]::GetFolderPath('ProgramFiles') + '\Steam')) {
        if ($p -and (Test-Path $p)) { $steamRoots.Add($p) }
    }

    $libraries = New-Object System.Collections.Generic.List[string]
    foreach ($root in ($steamRoots | Select-Object -Unique)) {
        $libraries.Add($root)
        $vdf = Join-Path $root 'steamapps\libraryfolders.vdf'
        if (Test-Path $vdf) {
            $raw = Get-Content -LiteralPath $vdf -Raw
            foreach ($m in [regex]::Matches($raw, '"path"\s+"([^"]+)"')) {
                $lib = $m.Groups[1].Value.Replace('\\','\')
                if ($lib -and (Test-Path $lib)) { $libraries.Add($lib) }
            }
        }
    }

    foreach ($lib in ($libraries | Select-Object -Unique)) {
        $candidate = Join-Path $lib 'steamapps\common\FPSAimTrainer\FPSAimTrainer'
        if (Test-Path (Join-Path $candidate 'Saved\SaveGames')) { return $candidate }
    }
    throw 'KovaaK''s Steam installation could not be found automatically. Make sure Steam/KovaaK''s is installed for this Windows user.'
}

function Set-MapValue($Map, [string]$Key, $Value) {
    $prop = $Map.PSObject.Properties[$Key]
    if ($null -ne $prop) { $prop.Value = $Value }
    else { $Map | Add-Member -NotePropertyName $Key -NotePropertyValue $Value }
}

function Ensure-JsonMap($Root, [string]$Name) {
    $p = $Root.PSObject.Properties[$Name]
    if ($null -eq $p) {
        $obj = New-Object PSObject
        $Root | Add-Member -NotePropertyName $Name -NotePropertyValue $obj
        return $obj
    }
    return $p.Value
}

function Set-IniValue([string]$Text, [string]$Key, [string]$Value) {
    $escaped = [regex]::Escape($Key)
    $pattern = '(?m)^\s*' + $escaped + '=.*$'
    if ([regex]::IsMatch($Text, $pattern)) {
        return [regex]::Replace($Text, $pattern, ($Key + '=' + $Value))
    }
    return ($Text.TrimEnd("`r","`n") + "`r`n" + $Key + '=' + $Value + "`r`n")
}

function Backup-Target([string]$Target, [string]$BackupRoot, [string]$Rel, $ManifestList) {
    $existed = Test-Path -LiteralPath $Target
    if ($existed) {
        $dest = Join-Path $BackupRoot $Rel
        New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force | Out-Null
        Copy-Item -LiteralPath $Target -Destination $dest -Force
    }
    $ManifestList.Add([pscustomobject]@{ target=$Target; backupRelative=$Rel; existed=[bool]$existed }) | Out-Null
}

Write-Host "[$ProfileName] Locating KovaaK's..." -ForegroundColor Cyan
$ProjectDir = Find-KovaaksProjectDir
$SaveGames = Join-Path $ProjectDir 'Saved\SaveGames'
$CrosshairDir = Join-Path $ProjectDir 'crosshairs'
$ConfigDir = Join-Path $env:LOCALAPPDATA 'FPSAimTrainer\Saved\Config\WindowsNoEditor'
New-Item -ItemType Directory -Path $CrosshairDir -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $SaveGames 'Themes') -Force | Out-Null
New-Item -ItemType Directory -Path $ConfigDir -Force | Out-Null

# Never modify live config while the game is running.
Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -in @('FPSAimTrainer','FPSAimTrainer-Win64-Shipping') } | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 300

$Primary = Join-Path $SaveGames 'PrimaryUserSettings.json'
$Weapon = Join-Path $SaveGames 'weaponsettings.ini'
$GameUser = Join-Path $ConfigDir 'GameUserSettings.ini'
$Palette = Join-Path $ConfigDir 'Palette.ini'
$Theme = Join-Path (Join-Path $SaveGames 'Themes') 'clover-alternate.json'
$Crosshair = Join-Path $CrosshairDir 'CS2_1280x960_s1_gap-4_th1_green.png'

foreach ($required in @($Primary,$Weapon,$GameUser)) {
    if (-not (Test-Path -LiteralPath $required)) { throw "Required KovaaK's file missing: $required" }
}

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$BackupRoot = Join-Path $ScriptRoot ('Backup\' + $stamp)
New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null
$backupItems = New-Object System.Collections.Generic.List[object]
Backup-Target $Primary $BackupRoot 'SaveGames\PrimaryUserSettings.json' $backupItems
Backup-Target $Weapon $BackupRoot 'SaveGames\weaponsettings.ini' $backupItems
Backup-Target $GameUser $BackupRoot 'WindowsNoEditor\GameUserSettings.ini' $backupItems
Backup-Target $Palette $BackupRoot 'WindowsNoEditor\Palette.ini' $backupItems
Backup-Target $Theme $BackupRoot 'SaveGames\Themes\clover-alternate.json' $backupItems
Backup-Target $Crosshair $BackupRoot 'crosshairs\CS2_1280x960_s1_gap-4_th1_green.png' $backupItems
$backupManifest = [pscustomobject]@{ created=(Get-Date).ToString('o'); profile=$ProfileName; items=$backupItems }
Write-Utf8NoBom (Join-Path $BackupRoot 'backup_manifest.json') ($backupManifest | ConvertTo-Json -Depth 8)

Write-Host "Backup: $BackupRoot" -ForegroundColor DarkGray

# Assets
Copy-Item -LiteralPath (Join-Path $ScriptRoot 'Assets\Themes\clover-alternate.json') -Destination $Theme -Force
Copy-Item -LiteralPath (Join-Path $ScriptRoot 'Assets\crosshairs\CS2_1280x960_s1_gap-4_th1_green.png') -Destination $Crosshair -Force
Copy-Item -LiteralPath (Join-Path $ScriptRoot 'Assets\Config\Palette.ini') -Destination $Palette -Force

# PrimaryUserSettings.json: patch existing schema instead of wholesale replacement, so new KovaaK's keys survive updates.
$cfg = Get-Content -LiteralPath $Primary -Raw | ConvertFrom-Json
$b = Ensure-JsonMap $cfg 'booleanSettings'
$i = Ensure-JsonMap $cfg 'integerSettings'
$f = Ensure-JsonMap $cfg 'floatSettings'
$s = Ensure-JsonMap $cfg 'stringSettings'
$v = Ensure-JsonMap $cfg 'vectorSettings'
$c = Ensure-JsonMap $cfg 'colorSettings'

$bools = @{
 'EBooleanSettingId::AutoHideHealthbar'=$false;
 'EBooleanSettingId::ChangeEnemyColorOnHit'=$false;
 'EBooleanSettingId::ChangeEnemyColorOnLookAt'=$false;
 'EBooleanSettingId::DisableSeasonalContent'=$true;
 'EBooleanSettingId::EnableSeasonalContent'=$false;
 'EBooleanSettingId::FloatingCombatText'=$false;
 'EBooleanSettingId::HideGun'=$false;
 'EBooleanSettingId::OneFrameThreadLag'=$false;
 'EBooleanSettingId::OverrideAllNewMapMaterials'=$true;
 'EBooleanSettingId::OverrideEnemyBodyColor'=$true;
 'EBooleanSettingId::OverrideEnemyHeadColor'=$true;
 'EBooleanSettingId::OverrideMBSChangeNowSound'=$true;
 'EBooleanSettingId::SaveStatistics'=$true;
 'EBooleanSettingId::ShowHealthBars'=$true;
 'EBooleanSettingId::ShowInfoBars'=$false;
 'EBooleanSettingId::ShowSessionBestOnHighScoreBar'=$false;
 'EBooleanSettingId::ShowSunInSkybox'=$false;
 'EBooleanSettingId::ShowVersionDuringGameplay'=$false;
 'EBooleanSettingId::TextureStreaming'=$false;
 'EBooleanSettingId::TiledReflections'=$false;
 'EBooleanSettingId::YInvert'=$false
}
foreach ($k in $bools.Keys) { Set-MapValue $b $k $bools[$k] }

$ints = @{
 'EIntegerSettingId::Anisotropy'=0;
 'EIntegerSettingId::AntiAliasing'=0;
 'EIntegerSettingId::CloudCover'=0;
 'EIntegerSettingId::DPI'=1600;
 'EIntegerSettingId::Effects'=0;
 'EIntegerSettingId::FloorMat'=0;
 'EIntegerSettingId::InputLagFrameCount'=0;
 'EIntegerSettingId::LowLatencyMode'=1;
 'EIntegerSettingId::PostProcessing'=0;
 'EIntegerSettingId::SceneColorFormat'=2;
 'EIntegerSettingId::Shadows'=0;
 'EIntegerSettingId::SkyPreset'=6;
 'EIntegerSettingId::WallMat'=50
}
foreach ($k in $ints.Keys) { Set-MapValue $i $k $ints[$k] }

$floats = @{
 'EFloatSettingId::CeilingFullBright'=0.57287824153900146;
 'EFloatSettingId::CeilingMetallic'=1.0;
 'EFloatSettingId::CeilingRoughness'=1.0;
 'EFloatSettingId::CeilingTextureScale'=1.0;
 'EFloatSettingId::CountDownBeforeChallengeStart'=0.25;
 'EFloatSettingId::DecalTime'=0.0;
 'EFloatSettingId::EnemyFullBright'=0.10000000149011612;
 'EFloatSettingId::EnemyGlowUpBody'=1.0;
 'EFloatSettingId::EnemyGlowUpBodyOnHit'=1.0;
 'EFloatSettingId::EnemyGlowUpBodyOnLookAt'=1000.0;
 'EFloatSettingId::EnemyGlowUpHead'=1.0;
 'EFloatSettingId::EnemyGlowUpHeadOnHit'=1.0;
 'EFloatSettingId::EnemyGlowUpHeadOnLookAt'=1.0;
 'EFloatSettingId::EnemyMetalic'=0.49555161595344543;
 'EFloatSettingId::EnemyRoughness'=0.1502835601568222;
 'EFloatSettingId::EnemyVolume'=0.75;
 'EFloatSettingId::FloorFullBright'=0.80000001192092896;
 'EFloatSettingId::FloorMetallic'=0.0;
 'EFloatSettingId::FloorRoughness'=0.29096046090126038;
 'EFloatSettingId::FloorTextureScale'=1.0;
 'EFloatSettingId::FootstepVolume'=0.0;
 'EFloatSettingId::FOV'=90.0;
 'EFloatSettingId::Gamma'=1.8;
 'EFloatSettingId::MaxFPS'=5000.0;
 'EFloatSettingId::MenuMaxFPS'=400.0;
 'EFloatSettingId::MissVolume'=0.0;
 'EFloatSettingId::MusicVolume'=0.0;
 'EFloatSettingId::RampFullBright'=0.55000001192092896;
 'EFloatSettingId::RampMetallic'=0.72000002861022949;
 'EFloatSettingId::RampRoughness'=1.0;
 'EFloatSettingId::RampTextureScale'=1.0;
 'EFloatSettingId::ResolutionScale'=100.0;
 'EFloatSettingId::TeamGlowUpBody'=1.0;
 'EFloatSettingId::TeamGlowUpHead'=1.0;
 'EFloatSettingId::WallFullBright'=0.55000001192092896;
 'EFloatSettingId::WallMetallic'=1.0;
 'EFloatSettingId::WallRoughness'=1.0;
 'EFloatSettingId::WallTextureScale'=1.0;
 'EFloatSettingId::XSens'=0.475;
 'EFloatSettingId::YSens'=0.475
}
foreach ($k in $floats.Keys) { Set-MapValue $f $k $floats[$k] }

$strings = @{
 'EStringSettingId::CeilingMaterial'='MARBLE POLISHED';
 'EStringSettingId::CurrentThemeName'='clover-alternate';
 'EStringSettingId::FloorMaterial'='BRICK CLAY BEVELED';
 'EStringSettingId::FOVScaleString'='Counter-Strike';
 'EStringSettingId::KillConfirmedSound'='None';
 'EStringSettingId::MBSChangeNowSound'='None';
 'EStringSettingId::RampMaterial'='MARBLE POLISHED';
 'EStringSettingId::SensScaleString'='Counter-Strike';
 'EStringSettingId::SpawnSound'='None';
 'EStringSettingId::WallMaterial'='MARBLE POLISHED'
}
foreach ($k in $strings.Keys) { Set-MapValue $s $k $strings[$k] }

$vecs = @{
 'EVectorSettingId::CeilingColor'=[pscustomobject]@{x=1.0;y=1.0;z=1.0};
 'EVectorSettingId::EnemyBodyColor'=[pscustomobject]@{x=0.0;y=0.0;z=0.0};
 'EVectorSettingId::EnemyBodyColorOnHit'=[pscustomobject]@{x=1.0;y=1.0;z=1.0};
 'EVectorSettingId::EnemyBodyColorOnLookAt'=[pscustomobject]@{x=1.0;y=0.7758222222328186;z=0.0};
 'EVectorSettingId::EnemyHeadColor'=[pscustomobject]@{x=0.0;y=0.0;z=0.0};
 'EVectorSettingId::EnemyHeadColorOnHit'=[pscustomobject]@{x=1.0;y=1.0;z=1.0};
 'EVectorSettingId::EnemyHeadColorOnLookAt'=[pscustomobject]@{x=1.0;y=1.0;z=0.0};
 'EVectorSettingId::FloorColor'=[pscustomobject]@{x=1.0;y=1.0;z=1.0};
 'EVectorSettingId::RampColor'=[pscustomobject]@{x=1.0;y=1.0;z=1.0};
 'EVectorSettingId::TeamBodyColor'=[pscustomobject]@{x=0.0;y=0.0;z=0.0};
 'EVectorSettingId::TeamHeadColor'=[pscustomobject]@{x=0.0;y=0.0;z=0.0};
 'EVectorSettingId::WallColor'=[pscustomobject]@{x=1.0;y=1.0;z=1.0}
}
foreach ($k in $vecs.Keys) { Set-MapValue $v $k $vecs[$k] }
Set-MapValue $c 'EColorSettingId::SkyColor' ([pscustomobject]@{b=255;g=255;r=255;a=255})

Write-Utf8NoBom $Primary ($cfg | ConvertTo-Json -Depth 24)

# weaponsettings.ini: CS2-specific overrides and exact reconstructed crosshair.
$w = Get-Content -LiteralPath $Weapon -Raw
$weaponPatch = [ordered]@{
 'TracerVisible'='false';
 'ZoomSensMultiplier'='0.9';
 'WeaponHidden'='false';
 'CrosshairColor'='X=1.000 Y=1.000 Z=1.000';
 'Hitmarkers'='false';
 'CrosshairScale'='1.0';
 'CrosshairFile'='CS2_1280x960_s1_gap-4_th1_green.png';
 'ShowBloom'='false';
 'OverrideSens'='false';
 'HorizontalSens'='0.475';
 'VerticalSens'='0.475';
 'SensScale'='Counter-Strike';
 'OverrideFOV'='false';
 'FOV'='90.0';
 'EnableMissSound'='false';
 'FOVScale'='Counter-Strike';
 'OverrideFovScaleString'='Counter-Strike';
 'OverrideSensScaleString'='Counter-Strike'
}
foreach ($k in $weaponPatch.Keys) { $w = Set-IniValue $w $k $weaponPatch[$k] }
Write-Utf8NoBom $Weapon $w

# GameUserSettings.ini: 1280x960, 400 Hz, true exclusive fullscreen, VSync off, no secondary UE cap.
$g = Get-Content -LiteralPath $GameUser -Raw
$videoPatch = [ordered]@{
 'sg.ResolutionQuality'='100.000000';
 'sg.ViewDistanceQuality'='0';
 'sg.AntiAliasingQuality'='0';
 'sg.ShadowQuality'='0';
 'sg.PostProcessQuality'='0';
 'sg.TextureQuality'='0';
 'sg.EffectsQuality'='0';
 'sg.FoliageQuality'='0';
 'sg.ShadingQuality'='0';
 'bUseVSync'='False';
 'bUseDynamicResolution'='False';
 'ResolutionSizeX'='1280';
 'ResolutionSizeY'='960';
 'RefreshRate'='400';
 'LastUserConfirmedResolutionSizeX'='1280';
 'LastUserConfirmedResolutionSizeY'='960';
 'LastUserConfirmedRefreshRate'='400';
 'FullscreenMode'='0';
 'LastConfirmedFullscreenMode'='0';
 'PreferredFullscreenMode'='0';
 'FrameRateLimit'='0.000000';
 'DesiredScreenWidth'='1280';
 'DesiredScreenHeight'='960';
 'LastUserConfirmedDesiredScreenWidth'='1280';
 'LastUserConfirmedDesiredScreenHeight'='960'
}
foreach ($k in $videoPatch.Keys) { $g = Set-IniValue $g $k $videoPatch[$k] }
Write-Utf8NoBom $GameUser $g

# Verification: fail loudly if a key layer did not take.
$checks = New-Object System.Collections.Generic.List[string]
$fail = $false
function Check([bool]$Ok,[string]$Name) {
    if ($Ok) { $checks.Add('PASS  ' + $Name) | Out-Null }
    else { $script:fail=$true; $checks.Add('FAIL  ' + $Name) | Out-Null }
}
$vcfg = Get-Content -LiteralPath $Primary -Raw | ConvertFrom-Json
Check ([math]::Abs(($vcfg.floatSettings.PSObject.Properties['EFloatSettingId::XSens'].Value) - 0.475) -lt 0.000001) 'Sensitivity X = 0.475'
Check ([math]::Abs(($vcfg.floatSettings.PSObject.Properties['EFloatSettingId::YSens'].Value) - 0.475) -lt 0.000001) 'Sensitivity Y = 0.475'
Check (($vcfg.integerSettings.PSObject.Properties['EIntegerSettingId::DPI'].Value) -eq 1600) 'DPI = 1600'
Check (($vcfg.stringSettings.PSObject.Properties['EStringSettingId::FOVScaleString'].Value) -eq 'Counter-Strike') 'FOV scale = Counter-Strike'
Check (($vcfg.floatSettings.PSObject.Properties['EFloatSettingId::FOV'].Value) -eq 90) 'FOV = 90'
Check (($vcfg.floatSettings.PSObject.Properties['EFloatSettingId::ResolutionScale'].Value) -eq 100) 'Resolution scale = 100'
Check (($vcfg.stringSettings.PSObject.Properties['EStringSettingId::CurrentThemeName'].Value) -eq 'clover-alternate') 'Theme = clover-alternate'
Check (Test-Path -LiteralPath $Crosshair) 'Exact CS2 crosshair asset installed'
Check (Test-Path -LiteralPath $Theme) 'Theme asset installed'
$vg = Get-Content -LiteralPath $GameUser -Raw
Check ($vg -match '(?m)^ResolutionSizeX=1280\r?$' -and $vg -match '(?m)^ResolutionSizeY=960\r?$') 'Resolution = 1280x960'
Check ($vg -match '(?m)^RefreshRate=400\r?$') 'Refresh = 400 Hz'
Check ($vg -match '(?m)^FullscreenMode=0\r?$') 'Exclusive fullscreen'
Check ($vg -match '(?m)^bUseVSync=False\r?$') 'VSync = Off'
Check ($vg -match '(?m)^FrameRateLimit=0\.000000\r?$') 'UE secondary FPS cap = Off'

$reportLines = New-Object System.Collections.Generic.List[string]
$reportLines.Add($ProfileName) | Out-Null
$reportLines.Add('Applied: ' + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')) | Out-Null
$reportLines.Add('KovaaK project: ' + $ProjectDir) | Out-Null
$reportLines.Add('Backup: ' + $BackupRoot) | Out-Null
$reportLines.Add('') | Out-Null
foreach ($line in $checks) { $reportLines.Add([string]$line) | Out-Null }
$reportLines.Add('') | Out-Null
$reportLines.Add('Stretched note: this profile forces 1280x960 exclusive fullscreen. GPU/display scaling remains controlled by your NVIDIA/AMD/display scaling setting; because CS2 already runs 1280x960 stretched on this PC, KovaaK''s should inherit the same full-screen scaling path.') | Out-Null
$report = $reportLines -join "`r`n"
Write-Utf8NoBom (Join-Path $ScriptRoot 'LastVerification.txt') $report

if ($fail) {
    Write-Host $report -ForegroundColor Yellow
    throw 'Standard was applied but one or more verification checks failed. See LastVerification.txt. Your pre-change backup is intact.'
}

Write-Host ''
Write-Host 'KOVAAKS CS2 STANDARD V1 APPLIED + VERIFIED' -ForegroundColor Green
Write-Host '1280x960 stretched | 400 Hz | VSync Off | Fullscreen' -ForegroundColor Green
Write-Host '1600 DPI | CS2 0.475 | Counter-Strike FOV 90' -ForegroundColor Green
Write-Host 'Exact CS2 crosshair | clover-alternate | kill/spawn sounds off' -ForegroundColor Green
Write-Host "Backup saved to: $BackupRoot" -ForegroundColor DarkGray
Write-Host 'You can now launch KovaaK''s normally through Steam.' -ForegroundColor Cyan
