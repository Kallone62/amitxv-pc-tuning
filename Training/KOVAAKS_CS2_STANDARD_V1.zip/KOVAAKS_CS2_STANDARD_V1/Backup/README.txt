Apply script creates timestamped backups here. Do not delete them until you are satisfied with the profile.
