@echo off
setlocal
cd /d "%~dp0"
echo Applying KOVAAKS_CS2_STANDARD_V1...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Apply-KOVAAKS-CS2-STANDARD.ps1"
set ERR=%ERRORLEVEL%
echo.
if not "%ERR%"=="0" (
  echo ERROR: Apply failed. Read the message above; your backup was not deleted.
) else (
  echo Done. LastVerification.txt contains the verification result.
)
pause
exit /b %ERR%
