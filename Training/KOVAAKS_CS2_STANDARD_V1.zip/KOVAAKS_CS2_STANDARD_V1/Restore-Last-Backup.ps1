$ErrorActionPreference='Stop'
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$backupBase = Join-Path $ScriptRoot 'Backup'
if (-not (Test-Path $backupBase)) { throw 'Backup folder does not exist.' }
$latest = Get-ChildItem -LiteralPath $backupBase -Directory | Sort-Object Name -Descending | Select-Object -First 1
if ($null -eq $latest) { throw 'No backup snapshot was found.' }
$manifestPath = Join-Path $latest.FullName 'backup_manifest.json'
if (-not (Test-Path $manifestPath)) { throw "Backup manifest missing: $manifestPath" }
$m = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -in @('FPSAimTrainer','FPSAimTrainer-Win64-Shipping') } | Stop-Process -Force -ErrorAction SilentlyContinue
foreach ($item in $m.items) {
    $target = [string]$item.target
    if ([bool]$item.existed) {
        $src = Join-Path $latest.FullName ([string]$item.backupRelative)
        if (-not (Test-Path -LiteralPath $src)) { throw "Backup file missing: $src" }
        New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
        Copy-Item -LiteralPath $src -Destination $target -Force
    } else {
        if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Force }
    }
}
Write-Host "Restored latest backup: $($latest.FullName)" -ForegroundColor Green
