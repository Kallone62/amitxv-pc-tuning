@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Restore-Last-Backup.ps1"
set ERR=%ERRORLEVEL%
echo.
pause
exit /b %ERR%
