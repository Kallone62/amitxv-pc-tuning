# KOVAAKS_CS2_STANDARD_V1

Tek profil. Sadece CS2 icin. Senaryoya gore sens/FOV/theme degistirme yok.

## Uygulanan temel standart

- Resolution: **1280x960, 4:3 stretched**
- Display: **Exclusive Fullscreen**
- Refresh: **400 Hz**
- VSync: **Off**
- Resolution Scale: **100%**
- Mouse DPI: **1600**
- Sensitivity Scale: **Counter-Strike**
- X/Y Sens: **0.475 / 0.475** (1:1)
- Fiziksel sens: **~54.689 cm/360**
- FOV Scale: **Counter-Strike**
- FOV: **90**
- Kovaak gameplay FPS limit: **5000** (effectively uncapped)
- Unreal secondary `FrameRateLimit`: **0**
- Menu FPS: **400**
- VSync off, AA/effects/shadows/post-processing off, texture streaming off, tiled reflections off
- InputLagFrameCount: **0**
- LowLatencyMode: **1**
- OneFrameThreadLag: **Off**
- Theme: **MattyOW `clover-alternate`**
- Palette: MattyOW palette
- Crosshair: CS2 autoexec'teki `style 4 / size 1 / gap -4 / thickness 1 / dot off / outline off / color 1` degerlerinden **1280x960 piksel duzeyinde yeniden olusturuldu**.
- Zoom sens multiplier: **0.9**
- Kill-confirmed sound: **Off**
- Spawn sound: **Off**
- Statistics: **On**

## Kurulum

1. ZIP'i normal bir klasore cikart.
2. `Apply-KOVAAKS-CS2-STANDARD.bat` dosyasina cift tikla.
3. Script KovaaK's aciksa kapatir, mevcut hedef dosyalari `Backup\<timestamp>` altina yedekler, standardi uygular ve kritik degerleri dogrular.
4. `LastVerification.txt` icinde PASS/FAIL raporu olusur.
5. Sonra KovaaK's'i Steam'den normal sekilde ac.

Admin yetkisi normalde gerekmez. Steam kutuphanesi registry + `libraryfolders.vdf` uzerinden otomatik bulunur; D:/E: gibi farkli Steam Library'leri de taranir.

## Stretched hakkinda

Bu paket KovaaK's'i **1280x960 exclusive fullscreen** yapar. 4:3 -> paneli dolduracak stretch davranisini NVIDIA/AMD/display scaling yapar; Kovaak config dosyasi vendor-agnostic olarak GPU scaling modunu guvenilir bicimde zorlayamaz. Bu PC'de CS2 zaten ayni 1280x960'u stretched calistirdigi icin KovaaK's normalde ayni full-screen scaling yolunu devralir. Eger ilk acilista black bars gorursen GPU scaling tarafinda `Full-screen` seceneginin bir kez dogru oldugunu kontrol etmen gerekir.

## Neden MattyOW UI.json yok?

MattyOW'un UI.json dosyasindaki HUD pozisyonlari 1920x1080 koordinatlari (ornegin x~1800) kullaniyor. 1280x960'a onu korlemesine kopyalamak elementleri ekran disina atabilir. Bu nedenle **theme/palette/performance mantigini aliyoruz, 1920x1080 UI pozisyonlarini almiyoruz**.

## Neden sounds klasoru yok?

Bu CS2 standardinda kill/spawn sound kapali. Bu yuzden buyuk MattyOW sound paketini tasimak gereksiz; profil icin kullanilmayan ses dosyalari bilerek paketlenmedi.

## OneFrameThreadLag karari

MattyOW configinde bu `On`; senin mevcut configinde `Off`. KovaaK'in gelistiricisi bu secenegin sistemden sisteme degisebildigini belirtmis. Olcum yapmadan render-ahead eklememek icin V1'de **Off** birakildi. Bu, videodan korlemesine kopyalamadigimiz sistem-bagimli tek kritik latency tercihlerinden biri.

## Kaynak politikasi

- MattyOW: environment/theme/palette + low graphics baseline
- Viscose: resolution/refresh/VSync/high-FPS metodolojisi
- Biley: CS2 odakli uygulama ve sade feedback
- Senin CS2 autoexec: sens, zoom ratio, crosshair ve CS2-specific degerlerde son soz

Public MattyOW archive: https://github.com/1234/kovaak-mattyow-settings
KovaaK settings docs: https://wiki.kovaaks.com/en/home/KovaaK%27s/Settings
KovaaK video settings docs: https://wiki.kovaaks.com/en/home/KovaaK%27s/Settings/video

## Geri alma

`Restore-Last-Backup.bat` son apply oncesindeki dosyalari geri getirir. Standart tarafindan yeni olusturulan assetler daha once yoksa restore sirasinda silinir.

## V1 package hotfix

`1.0.1-verification-report-hotfix`: `LastVerification.txt` icindeki PASS/FAIL listesinin `System.Collections.Generic.List...` olarak gorunmesine neden olan PowerShell raporlama hatasi duzeltildi. Oyun/config ayarlari degismedi.
